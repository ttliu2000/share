﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LanguageServer.VsCode
{
    internal static class Utility
    {
        // Defined by the protocol.
        public const int RequestCancelledErrorCode = -32800;
    }
}
