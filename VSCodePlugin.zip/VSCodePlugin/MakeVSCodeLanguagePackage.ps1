#deploy the language server DLL to deploy

#assume the current path is 1 level above the DemoLanguage server
$serverDLLPath = ".\DemoLanguageServer\bin\Debug\net6.0\"
$vscodePackageClientPath = ".\Client\VsCode\"

$vsCodePackageServerPath = [System.IO.Path]::Combine($vscodePackageClientPath, "server\")

#check if the server DLL path is valid
if (-not (Test-Path $serverDLLPath))
{
    Write-Error "$serverDLLPath does not exist"
    exit -1
}
else 
{
    Write-Verbose "$serverDLLPath exists and can continue"
}

if (Test-Path $vsCodePackageServerPath) 
{
    Write-Verbose "$vsCodePackageServerPath exists and ignore creation folder"
}
else 
{
    Write-Verbose "creating $vsCodePackageServerPath"
    New-Item -Path $vsCodePackageServerPath -ItemType Directory
}

#copy everything under server DLL path to server path
$source = [System.IO.Path]::Combine($serverDLLPath, "*")
Write-Verbose "source identifier is $source"
Copy-Item -Path $source -Destination $vsCodePackageServerPath -Force –Recurse

Write-Verbose "Start packaging stage"
$vsPacakgeFile = "RiscVAssemblyLanguageVSCodePlugin.vsix"

Write-Verbose "change location to $vscodePackageClientPath"
$currentLocation = Get-Location

Push-Location $vscodePackageClientPath

Write-Verbose "output $vsPacakgeFile to the current folder: $currentLocation"
$vsixFile = [System.IO.Path]::Combine($currentLocation, $vsPacakgeFile)
vsce package --out $vsixFile

Pop-Location

Write-Host "\r\nOpen the VSCode, click the extension from VSCode UI, and install VSIX"